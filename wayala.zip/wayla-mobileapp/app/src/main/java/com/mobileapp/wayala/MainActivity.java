package com.mobileapp.wayala;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "MainActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void logIn(View v){
        boolean login = false;
        EditText email = findViewById(R.id.mainViewUserEmail);
        EditText pass = findViewById(R.id.mainViewUserPassword);
        FirebaseFirestore db = FirebaseFirestore.getInstance();
       Task<QuerySnapshot> query =  db.collection(getString(R.string.collection_id))
                .whereEqualTo("email", email.getText().toString()).whereEqualTo("password",pass.getText().toString())
                .get();
       query.addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if (task.isSuccessful()) {
                    if (task.getResult().isEmpty()) {

                        Toast.makeText(getApplicationContext(), "Email ou password errados!", Toast.LENGTH_LONG).show();

                    } else {
                        task.getResult().getDocuments().get(0).getId();
                        Intent intent = new Intent(getApplicationContext(), MenuActivity.class);
                        startActivity(intent);
                        Log.d(TAG,"Log in sucesso");
                    }
                }
            }
        });

    }

    public void registerUser(View v){
        Intent intent = new Intent(this, RegisterActivity.class);
        startActivity(intent);
    }


}