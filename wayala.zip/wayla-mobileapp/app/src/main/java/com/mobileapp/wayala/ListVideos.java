package com.mobileapp.wayala;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class ListVideos extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_videos);
    }

    public  void openVideo(View v){
        Intent intent = new Intent(this,VideoPlayer.class);
        startActivity(intent);
    }
}