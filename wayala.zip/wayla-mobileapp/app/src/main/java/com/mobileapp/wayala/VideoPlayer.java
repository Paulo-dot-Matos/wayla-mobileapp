package com.mobileapp.wayala;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RatingBar;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.youtube.player.YouTubeBaseActivity;
import com.google.android.youtube.player.YouTubeInitializationResult;
import com.google.android.youtube.player.YouTubePlayer;
import com.google.android.youtube.player.YouTubePlayerView;
import com.google.firebase.Timestamp;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.gson.internal.$Gson$Preconditions;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class VideoPlayer extends YouTubeBaseActivity {

    private static  final String USER_ID="68uVROMe9ER9I77ISWOZ";
    private static  final String SONY_MOVIE_ID="vfXCCDlJrTJQx0vuL8Rm";
    private static  final String REVIEWS_COLLECTION_ID="reviews";
    private static  final String MOVIES_COLLECTION_ID="movies";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video_player);

        YouTubePlayerView youTubeView = (YouTubePlayerView) findViewById(R.id.videoPlayer);
        youTubeView.initialize("AIzaSyAk4i4ZixYPXqRm_z6rpdyNSj7x3Nu25NU",new YouTubePlayer.OnInitializedListener() {
            @Override
            public void onInitializationSuccess(YouTubePlayer.Provider provider, YouTubePlayer youTubePlayer, boolean b) {
                youTubePlayer.loadVideo("0_bx8bnCoiU");
            }

            @Override
            public void onInitializationFailure(YouTubePlayer.Provider provider, YouTubeInitializationResult youTubeInitializationResult) {

            }
        });
    }

    public void clearText(View v){
        EditText text = (EditText) findViewById(R.id.videoReviewText);
        text.setText("");
    }

    public void sendReview(View v){
        EditText text = (EditText) findViewById(R.id.videoReviewText);
        RatingBar ratingBar = (RatingBar) findViewById(R.id.videoRating);
        Map<String,Object> data = new HashMap<>();
        data.put("comment",text.getText().toString());
        data.put("createdAt",new Timestamp(new Date()));
        data.put("owner",USER_ID);
        data.put("rate",ratingBar.getRating());
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        db.collection(MOVIES_COLLECTION_ID).document(SONY_MOVIE_ID).collection(REVIEWS_COLLECTION_ID).add(data).addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
            @Override
            public void onSuccess(DocumentReference documentReference) {
                Log.d("VIDEO-PLAYER", "DocumentSnapshot written with ID: " + documentReference.getId());

                Toast.makeText(getApplicationContext(), "Review gravada com sucesso!", Toast.LENGTH_LONG).show();
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(getApplicationContext(), "Something went wrong try again later!", Toast.LENGTH_LONG).show();
            }
        });

    }


}